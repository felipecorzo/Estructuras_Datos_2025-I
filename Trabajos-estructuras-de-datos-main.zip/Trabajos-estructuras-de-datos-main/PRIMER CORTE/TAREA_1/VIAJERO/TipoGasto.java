public enum TipoGasto {
    COMIDA, HOSPEDAJE, TRANSPORTE, ROPA;
}

